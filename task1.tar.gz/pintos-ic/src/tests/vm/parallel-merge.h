#ifndef TESTS_VM_PARALLEL_MERGE
#define TESTS_VM_PARALLEL_MERGE 1

void parallel_merge (const char *child_name, int exit_status);

#endif /* tests/vm/parallel-merge.h */
